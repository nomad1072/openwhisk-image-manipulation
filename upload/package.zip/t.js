var request = require("request");

var options = { method: 'POST',
  url: 'https://172.31.36.188/api/v1/namespaces/_/actions/processImage',
  qs: { blocking: 'true' },
  headers: 
   { 'Content-Type': 'application/json' },
  body: { key: '2.png' },
	        rejectUnauthorized: false,

  json: true,
  auth: {
  	user: '789c46b1-71f6-4ed5-8c54-816aa4f8c502',
	pass: 'abczO3xZCLrMN6v2BKK1dXYFpXlPkccOFqm12CdAsMgRU4VrNZ9lyGVCGuMDGIwP'
  }};

request(options, function (error, response, body) {
  if (error) throw new Error(error);

  console.log(body);
});

