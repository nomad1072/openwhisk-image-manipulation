const shell = require('shelljs');
shell.exec('/root/openwhisk-devtools/docker-compose/openwhisk-src/bin/wsk -i package list')
