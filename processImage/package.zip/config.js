module.exports = {
    "aws_access_key": "AKIAJJIIK7ZQ5ATF7N7A",
    "aws_secret_access_key": "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"
}
